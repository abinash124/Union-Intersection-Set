The code was compiled and run in Intellij Environment.
Sourcefile: Main.java
Packagename: axb161031
Main sourcefile location: axb161031/src/Main.java
